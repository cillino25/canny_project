/*
 * opencv_funcs.h
 *
 *  Created on: 22 apr 2016
 *      Author: michele
 */

#ifndef OPENCV_FUNCS_H_
#define OPENCV_FUNCS_H_


//#include "opencv2/opencv.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"
//#include "opencv2/imgproc/imgproc_c.h"
#include "opencv2/core.hpp"

#include "opencv_Gblur.h"
#include "opencv_Canny.h"


#endif /* OPENCV_FUNCS_H_ */
